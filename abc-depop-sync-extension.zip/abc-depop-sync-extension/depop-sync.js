(() => {
  if (window.__ABC_DEPOP_SYNC_RUNNING__) return;
  window.__ABC_DEPOP_SYNC_RUNNING__ = true;

  const FUNCTION_URL = 'https://fuhphebvnstgszapvitz.supabase.co/functions/v1/resale-sync';

  function cleanText(value) { return String(value || '').replace(/\s+/g, ' ').replace(/\u00a0/g, ' ').trim(); }
  function titleCase(value) { return cleanText(value).split(' ').filter(Boolean).map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' '); }
  function parseMoney(value) { const m = cleanText(value).match(/\$[\d,]+(?:\.\d+)?/); return m ? Number(m[0].replace(/[$,]/g, '')) : 0; }
  function canonicalizeDepopUrl(href) {
    try { const u = new URL(href, window.location.origin); return `${u.origin}${u.pathname.replace(/\/+$/, '')}`; }
    catch { return cleanText(href).replace(/[?#].*$/, '').replace(/\/+$/, ''); }
  }
  function getDepopProductToken(href) {
    const slug = (canonicalizeDepopUrl(href).split('/products/')[1] || '').split('/')[0];
    if (!slug) return '';
    const parts = slug.split('-').filter(Boolean);
    return parts.length ? parts[parts.length - 1].toLowerCase() : '';
  }
  function getDescriptionFromUrl(href) {
    const slug = (href.split('/products/')[1] || '').split('/')[0];
    if (!slug) return '';
    const parts = slug.split('-').filter(Boolean);
    if (parts.length <= 1) return titleCase(parts.join(' '));
    const trimmed = /^\d+$/.test(parts[parts.length - 1]) ? parts.slice(1, -1) : parts.slice(1);
    return titleCase(trimmed.join(' '));
  }
  function getBrand(description) {
    const normalized = cleanText(description);
    if (!normalized) return '';
    const brands = ['Lululemon','Nike','Adidas','Coach','Gucci','Louis Vuitton','Prada','Jordan','Disney','Hello Kitty'];
    return brands.find(b => normalized.toLowerCase().includes(b.toLowerCase())) || normalized.split(' ')[0];
  }
  function buildOverlay() {
    const old = document.getElementById('abc-depop-sync-overlay'); if (old) old.remove();
    const o = document.createElement('div'); o.id = 'abc-depop-sync-overlay';
    o.style.cssText = 'position:fixed;top:20px;right:20px;z-index:2147483647;max-width:370px;padding:18px 20px;border-radius:16px;background:#111827;color:#f8fafc;box-shadow:0 20px 40px rgba(15,23,42,.35);font:14px/1.5 Arial,sans-serif';
    o.innerHTML = '<strong style="display:block;font-size:15px;margin-bottom:8px">ABC Depop Sync</strong><div id="abc-depop-sync-status">Starting…</div>';
    document.body.appendChild(o); return o;
  }
  function setStatus(m) { const t = document.getElementById('abc-depop-sync-status'); if (t) t.innerHTML = m; }
  async function autoScrollListings() {
    let previousHeight = 0, stableRounds = 0;
    for (let round = 0; round < 35; round++) {
      window.scrollTo({ top: document.body.scrollHeight, behavior: 'instant' });
      await new Promise(r => setTimeout(r, 1200));
      const h = document.body.scrollHeight;
      stableRounds = h === previousHeight ? stableRounds + 1 : 0;
      previousHeight = h;
      if (stableRounds >= 2) break;
    }
    window.scrollTo({ top: 0, behavior: 'instant' });
    await new Promise(r => setTimeout(r, 400));
  }
  function isSoldItem(item) {
    const badge = Array.from(item.querySelectorAll('span,div,p')).some(n => cleanText(n.textContent).toLowerCase() === 'sold');
    if (badge) return true;
    const text = cleanText(item.textContent).toLowerCase();
    return /\bsold\b/.test(text) && !/\bfor sale\b/.test(text);
  }
  function getRecommendationMarker() {
    const markers = ['Based on this collection','Based on this item','You may also like','More like this'];
    return Array.from(document.querySelectorAll('h1,h2,h3,h4,p,span,div')).find(n => markers.includes(cleanText(n.textContent)));
  }
  function scrapeItems() {
    const marker = getRecommendationMarker();
    const rows = Array.from(document.querySelectorAll('li'))
      .filter(item => item.querySelector('a[href*="/products/"]'))
      .filter(item => { if (!marker) return true; const relation = item.compareDocumentPosition(marker); return Boolean(relation & Node.DOCUMENT_POSITION_FOLLOWING); })
      .map(item => {
        const link = item.querySelector('a[href*="/products/"]');
        const href = link ? canonicalizeDepopUrl(link.href) : '';
        const description = getDescriptionFromUrl(href);
        const price = parseMoney(cleanText(item.textContent));
        const productToken = getDepopProductToken(href);
        if (!description && !price && !href) return null;
        return { platform:'Depop', status:isSoldItem(item)?'Sold':'For Sale', brand:getBrand(description), description, price, url:href, sourceKey:productToken?`depop::${productToken}`:'', scrapedAt:new Date().toISOString() };
      }).filter(Boolean);
    const seen = new Set();
    return rows.filter(item => { const k=(item.url||item.sourceKey||'').toLowerCase(); if(!k||seen.has(k)) return false; seen.add(k); return true; });
  }

  async function main() {
    buildOverlay();
    try {
      setStatus('Loading all listings…');
      await autoScrollListings();
      setStatus('Reading For Sale and Sold listings…');
      const items = scrapeItems();
      if (!items.length) throw new Error('No Depop items found. Make sure the ABC is for XYZ profile is visible.');
      const sold = items.filter(i => i.status === 'Sold').length;
      const listed = items.filter(i => i.status === 'For Sale').length;
      setStatus(`Found ${items.length} items.<br>For sale: ${listed}<br>Sold: ${sold}<br><br>Updating Supabase…`);
      const response = await fetch(FUNCTION_URL, { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({action:'sync_inventory',platform:'depop',items}) });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || 'Sync failed');
      setStatus(`Sync complete ✓<br><br>Items: ${items.length}<br>For sale: ${listed}<br>Sold: ${sold}<br><br>Returning to Depop Status…`);
      setTimeout(() => chrome.runtime.sendMessage({ type:'ABC_DEPOP_SYNC_COMPLETE', items:items.length, sold, listed }), 1200);
    } catch (error) {
      setStatus(`Sync error: ${cleanText(error.message)}<br><br>This Depop tab will stay open so you can inspect it.`);
      window.__ABC_DEPOP_SYNC_RUNNING__ = false;
    }
  }

  main();
})();
