const DEPOP_SHOP = 'https://www.depop.com/abc_isfor_xyz/';
const INVENTORY_ROOT = 'https://architeketh.github.io/shoe-inventory-system/';

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === 'ABC_START_DEPOP_SYNC') {
    chrome.tabs.create({ url: DEPOP_SHOP, active: true }, (tab) => {
      sendResponse({ ok: true, tabId: tab?.id });
    });
    return true;
  }

  if (message?.type === 'ABC_DEPOP_SYNC_COMPLETE') {
    chrome.tabs.query({ url: `${INVENTORY_ROOT}*` }, (tabs) => {
      const target = tabs && tabs.length ? tabs[0] : null;
      if (target?.id) {
        chrome.tabs.update(target.id, { active: true, url: `${INVENTORY_ROOT}depop-status.html?sync=${Date.now()}` });
        if (target.windowId) chrome.windows.update(target.windowId, { focused: true });
      } else {
        chrome.tabs.create({ url: `${INVENTORY_ROOT}depop-status.html?sync=${Date.now()}`, active: true });
      }
    });
    sendResponse({ ok: true });
    return true;
  }
});
