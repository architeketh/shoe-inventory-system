(() => {
  if (document.getElementById('abc-depop-sync-extension-button')) return;

  const button = document.createElement('button');
  button.id = 'abc-depop-sync-extension-button';
  button.type = 'button';
  button.textContent = '↻ Sync Depop';
  button.title = 'Open your Depop shop, scrape listings, sync to Supabase, and return to Depop Status';
  button.style.cssText = [
    'position:fixed','right:18px','bottom:18px','z-index:2147483646',
    'border:0','border-radius:999px','padding:12px 18px','font:700 14px/1.2 Arial,sans-serif',
    'background:#111827','color:#fff','box-shadow:0 8px 24px rgba(0,0,0,.22)','cursor:pointer'
  ].join(';');

  button.addEventListener('click', () => {
    const original = button.textContent;
    button.disabled = true;
    button.textContent = 'Opening Depop…';
    chrome.runtime.sendMessage({ type: 'ABC_START_DEPOP_SYNC' }, () => {
      setTimeout(() => {
        button.disabled = false;
        button.textContent = original;
      }, 1500);
    });
  });

  document.body.appendChild(button);
})();
