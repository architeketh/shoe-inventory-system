ABC DEPOP SYNC — INSTALL ONCE

1. Unzip the abc-depop-sync-extension.zip file.
2. In Chrome, open chrome://extensions
3. Turn on Developer mode (upper-right).
4. Click Load unpacked.
5. Select the unzipped abc-depop-sync-extension folder.
6. Open the ABC Shoe Inventory site.
7. You should see a floating “↻ Sync Depop” button at the lower-right.

ONE-BUTTON WORKFLOW
- Click “↻ Sync Depop” in the Inventory app.
- The extension opens the ABC is for XYZ Depop shop.
- It automatically loads the profile, scrolls the listings, reads For Sale/Sold, price, URL and details, and sends them to the existing Supabase resale-sync function.
- When complete, it returns you to depop-status.html.

NOTES
- Keep the Depop tab open while the sync is running.
- You must already be able to view the ABC is for XYZ Depop shop in Chrome.
- This extension does not change the existing Inventory app, CSV exporter, or scraper files on GitHub.
